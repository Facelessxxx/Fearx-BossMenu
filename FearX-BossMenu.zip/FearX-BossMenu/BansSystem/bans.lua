local ESX = exports['es_extended']:getSharedObject()


local allowed_ban_license = GetConvar('allowed_ban_license', '')

CreateThread(function()
    exports.oxmysql:execute([[
        CREATE TABLE IF NOT EXISTS bossmenu_bans (
            license VARCHAR(64) PRIMARY KEY,
            ban_id VARCHAR(6) UNIQUE NOT NULL,
            name VARCHAR(100),
            reason TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
    ]])
end)

local function getLicense(src)
    for _, id in ipairs(GetPlayerIdentifiers(src)) do
        if id:match('license:') then return id end
    end
    return nil
end

local function generateBanID()
    local charset = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
    local id = ''
    for _ = 1, 6 do
        local i = math.random(1, #charset)
        id = id .. charset:sub(i, i)
    end
    return id
end

function sendBanWebhook(name, license, banID, reason)
    local webhook = Config.Webhooks and Config.Webhooks.BanLogs
    if not webhook then return end

    PerformHttpRequest(webhook, function() end, 'POST', json.encode({
        username = 'BossMenu Ban Logger',
        embeds = {{
            title = "🚫 Player Banned",
            color = 16711680,
            fields = {
                { name = "Player Name", value = name, inline = true },
                { name = "Ban ID", value = banID, inline = true },
                { name = "License", value = license, inline = false },
                { name = "Reason", value = reason, inline = false }
            },
            footer = { text = "FearX BossMenu Logs" },
            timestamp = os.date('!%Y-%m-%dT%H:%M:%SZ')
        }}
    }), { ['Content-Type'] = 'application/json' })
end

function banServerModder(src, reason)
    local license = getLicense(src)
    local name = GetPlayerName(src) or 'Unknown'
    local why = reason or 'Violation'

    if not license then
        license = "missing_license_" .. math.random(100000,999999)
        why = "Missing license (possible spoof or modder)"
    end

    local banID = generateBanID()

    exports.oxmysql:execute(
        'REPLACE INTO bossmenu_bans (license, ban_id, name, reason) VALUES (?, ?, ?, ?)',
        {license, banID, name, why}
    )

    sendBanWebhook(name, license, banID, why)

    DropPlayer(src, ('[Bossmenu] You are permanently banned.\n🪪 Ban ID: %s\n🎟️ License: %s\n📖 Reason: %s'):format(
        banID, license, why
    ))
end


RegisterCommand('banbossmenu', function(source, args)
    if source == nil then
        print('❌ Invalid player source (source is null). Command cannot be executed in the console.')
        return
    end


    local playerLicense = getLicense(source)


    if playerLicense ~= allowed_ban_license then
        TriggerClientEvent('esx:showNotification', source, '❌ You do not have permission to use this command.')
        return
    end


    local id = tonumber(args[1])
    local reason = table.concat(args, ' ', 2) or 'Manual Ban'
    if not id or not GetPlayerName(id) then
        print('Usage: /banbossmenu [id] [reason]')
        return
    end
    banServerModder(id, reason)
end, false) 

RegisterCommand('unbanbossmenu', function(source, args)
    if source == nil then
        print('❌ Invalid player source (source is null). Command cannot be executed in the console.')
        return
    end


    local playerLicense = getLicense(source)


    if playerLicense ~= allowed_ban_license then
        TriggerClientEvent('esx:showNotification', source, '❌ You do not have permission to use this command.')
        return
    end


    local banID = args[1]
    if not banID then
        print('Usage: /unbanbossmenu [banid]')
        return
    end

    exports.oxmysql:execute('DELETE FROM bossmenu_bans WHERE ban_id = ?', {banID}, function(rows)
        if rows > 0 then
            print('✅ Unbanned ban ID: ' .. banID)
        else
            print('❌ No matching ban ID: ' .. banID)
        end
    end)
end, false)  

AddEventHandler('playerConnecting', function(name, setKickReason, deferrals)
    local src = source
    if not src then
        print('❌ Invalid player source (source is null).')
        deferrals.done('Connection error: invalid source.')
        return
    end

    deferrals.defer()
    Wait(0)

    deferrals.update('🔐 Checking ban list...')
    local license = getLicense(src)
    if not license then
        deferrals.done('🚫 Missing license.')
        return
    end

    local result = nil
    local ready = false

    exports.oxmysql:query('SELECT * FROM bossmenu_bans WHERE license = ?', {license}, function(res)
        result = res and res[1]
        ready = true
    end)

    local start = GetGameTimer()
    while not ready and GetGameTimer() - start < 5000 do Wait(50) end

    if not ready then
        print(('[Bossmenu] ⚠️ SQL timeout while checking ban for %s (%s)'):format(name, license))
        deferrals.done()
        return
    end

    if result then
        deferrals.done(('[Bossmenu] You are permanently banned.\n🪪 Ban ID: %s\n🎟️ License: %s\n📖 Reason: %s\n📅 Date: %s'):format(
            result.ban_id, result.license, result.reason, result.created_at
        ))
    else
        deferrals.done()
    end
end)
