Webhook = {}

Webhook.Send = function(title, description, fields, webhookURL)
    if not webhookURL then return end

    local embed = {
        title = title,
        description = description or "",
        color = 16711680,
        fields = fields or {},
        footer = { text = "🪄 BossMenu Logs" },
        timestamp = os.date('!%Y-%m-%dT%H:%M:%SZ')
    }

    PerformHttpRequest(webhookURL, function() end, 'POST', json.encode({
        username = "BossMenu Logger",
        embeds = { embed }
    }), { ['Content-Type'] = 'application/json' })
end

Webhook.BanLog = function(name, license, banID, reason, webhookURL)
    Webhook.Send(
        "🚫 Player Banned",
        nil,
        {
            { name = "Name", value = name or "Unknown", inline = true },
            { name = "License", value = license or "N/A", inline = true },
            { name = "Ban ID", value = banID or "-", inline = true },
            { name = "Reason", value = reason or "Unknown", inline = false },
        },
        webhookURL
    )
end

Webhook.UnbanLog = function(banID, license, webhookURL)
    Webhook.Send(
        "✅ Player Unbanned",
        nil,
        {
            { name = "Ban ID", value = banID or "-", inline = true },
            { name = "License", value = license or "Unknown", inline = false }
        },
        webhookURL
    )
end
