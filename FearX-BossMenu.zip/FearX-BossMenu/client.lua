local Config = Config or {}
local ESX = exports['es_extended']:getSharedObject()
local EventKey = nil

RegisterNetEvent('bossmenu:receiveEventKey', function(key)
    EventKey = key
end)

TriggerServerEvent('bossmenu:requestEventKey')


-- Load ESX data
CreateThread(function()
    while not ESX.IsPlayerLoaded() do Wait(100) end
    ESX.PlayerData = ESX.GetPlayerData()
end)

RegisterNetEvent('esx:playerLoaded', function(data)
    ESX.PlayerData = data
end)

RegisterNetEvent('esx:setJob', function(job)
    ESX.PlayerData.job = job
end)

local function isBossOfJob(jobName)
    local job = ESX.PlayerData and ESX.PlayerData.job
    if not job or job.name ~= jobName then return false end
    local rank = Config.Ranks[job.name]
    return rank and rank[job.grade] and rank[job.grade].boss == true
end


local function openBossMenu()
    lib.callback('boss:isBoss', false, function(isBoss)
        if not isBoss then
            lib.notify({ title = 'Access Denied', description = 'Only a boss can use this.', type = 'error' })
            return
        end

        lib.registerContext({
            id = 'boss_menu',
            title = 'Boss Menu',
            options = {
                {
                    title = ' View Employees',
                    icon = 'users',
                    onSelect = function()
                        lib.callback('boss:getEmployeesList', false, function(list)
                            if not list or #list == 0 then
                                lib.notify({ title = 'No Employees', description = 'Nobody hired yet.', type = 'error' })
                                return
                            end

                            local empOptions = {}
                            for _, emp in pairs(list) do
                                table.insert(empOptions, {
                                    title = ('%s (%s)%s'):format(emp.name, emp.grade_name, emp.isBoss and ' ' or ''),
                                    icon = emp.isBoss and 'crown' or 'user',
                                    onSelect = function()
                                        local opts = {}

                                        if not emp.isBoss then
                                            table.insert(opts, {
                                                title = ' Fire ' .. emp.name,
                                                icon = 'user-minus',
                                                onSelect = function()
                                                    TriggerServerEvent('boss:firePlayer', emp.id)
                                                    lib.notify({
                                                        title = 'Fired',
                                                        description = emp.name .. ' has been fired.',
                                                        type = 'success'
                                                    })
                                                end
                                            })
                                        else
                                            table.insert(opts, {
                                                title = ' This is you (Boss)',
                                                icon = 'check',
                                                readOnly = true
                                            })
                                        end

                                        lib.registerContext({
                                            id = 'employee_' .. emp.id,
                                            title = emp.name .. ' - ' .. emp.grade_name,
                                            menu = 'employee_list',
                                            options = opts
                                        })

                                        lib.showContext('employee_' .. emp.id)
                                    end
                                })
                            end

                            lib.registerContext({
                                id = 'employee_list',
                                title = 'Employee List',
                                menu = 'boss_menu',
                                options = empOptions
                            })

                            lib.showContext('employee_list')
                        end)
                    end
                },
                {
                    title = ' Hire Player',
                    icon = 'user-plus',
                    onSelect = function()
                        lib.callback('boss:getJobGrades', false, function(grades)
                            if not grades or #grades == 0 then
                                lib.notify({ title = 'Error', description = 'No job grades found.', type = 'error' })
                                return
                            end

                            local input = lib.inputDialog('Hire Player', {
                                { type = 'number', label = 'Player ID', required = true },
                                { type = 'select', label = 'Job Grade', required = true, options = grades }
                            })

                            if input then
                                TriggerServerEvent('boss:hirePlayer', input[1], input[2])
                            end
                        end)
                    end
                },
                {
                    title = ' Company Bank',
                    icon = 'building-columns',
                    onSelect = function()
                        local function refreshBankMenu()
                            lib.callback('boss:getSocietyMoney', false, function(balance)
                                balance = tonumber(balance) or 0

                                lib.registerContext({
                                    id = 'boss_bank',
                                    title = 'Company Bank: $' .. balance,
                                    menu = 'boss_menu',
                                    options = {
                                        {
                                            title = ' Deposit Money',
                                            icon = 'arrow-up',
                                            onSelect = function()
                                                local input = lib.inputDialog('Deposit', {
                                                    { type = 'number', label = 'Amount', required = true }
                                                })

                                                local amt = tonumber(input and input[1])
                                                if amt and amt > 0 then
                                                    TriggerServerEvent('boss:depositMoney', amt)
                                                    Wait(300)
                                                    refreshBankMenu()
                                                end
                                            end
                                        },
                                        {
                                            title = ' Withdraw Money',
                                            icon = 'arrow-down',
                                            onSelect = function()
                                                local input = lib.inputDialog('Withdraw', {
                                                    { type = 'number', label = 'Amount', required = true }
                                                })

                                                local amt = tonumber(input and input[1])
                                                if amt and amt > 0 then
                                                    TriggerServerEvent('boss:withdrawMoney', amt)
                                                    Wait(300)
                                                    refreshBankMenu()
                                                end
                                            end
                                        },
                                        {
                                            title = ' View Transactions',
                                            icon = 'book-open',
                                            onSelect = function()
                                                lib.callback('boss:getBankLogs', false, function(logs)
                                                    local options = {}
                                                    for _, entry in ipairs(logs) do
                                                        table.insert(options, {
                                                            title = entry,
                                                            icon = 'circle-dot',
                                                            readOnly = true
                                                        })
                                                    end

                                                    lib.registerContext({
                                                        id = 'boss_bank_log',
                                                        title = 'Last Transactions',
                                                        menu = 'boss_bank',
                                                        options = options
                                                    })

                                                    lib.showContext('boss_bank_log')
                                                end)
                                            end
                                        }
                                    }
                                })

                                lib.showContext('boss_bank')
                            end)
                        end

                        refreshBankMenu()
                    end
                }
            }
        })

        lib.showContext('boss_menu')
    end)
end

if Config.EnableCommand then
    RegisterCommand('bossmenu', openBossMenu)
end

CreateThread(function()
    if not Config.BossLocations then return end
    for _, loc in pairs(Config.BossLocations) do
        lib.zones.sphere({
            coords = loc.coords,
            radius = 1.5,
            debug = false,
            inside = function()
                if isBossOfJob(loc.job) then
                    lib.showTextUI(loc.label or '[E] Boss Menu')
                    if IsControlJustReleased(0, 38) then
                        openBossMenu()
                    end
                end
            end,
            onExit = function()
                lib.hideTextUI()
            end
        })
    end
end)


CreateThread(function()
    while true do
        Wait(0)
        if not Config.Marker or not Config.Marker.draw then return end

        local ply = GetEntityCoords(PlayerPedId())
        local job = ESX.PlayerData and ESX.PlayerData.job and ESX.PlayerData.job.name
        local grade = ESX.PlayerData and ESX.PlayerData.job and ESX.PlayerData.job.grade
        local isBoss = Config.Ranks[job] and Config.Ranks[job][grade] and Config.Ranks[job][grade].boss == true

        for _, loc in pairs(Config.BossLocations) do
            if job == loc.job and isBoss and #(ply - loc.coords) < 15.0 then
                DrawMarker(
                    Config.Marker.type or 21,
                    loc.coords.x, loc.coords.y, loc.coords.z - 0.98,
                    0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                    Config.Marker.scale.x, Config.Marker.scale.y, Config.Marker.scale.z,
                    Config.Marker.color.r, Config.Marker.color.g, Config.Marker.color.b, Config.Marker.color.a,
                    false, false, 2, false, nil, nil, false
                )
            end
        end
    end
end)
