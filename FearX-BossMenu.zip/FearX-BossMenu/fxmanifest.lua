fx_version 'cerulean'
game 'gta5'

lua54 'yes'

shared_script '@ox_lib/init.lua'

client_script 'client.lua'
server_script 'server.lua'
server_script 'BansSystem/bans.lua'
server_script 'BansSystem/webhook.lua'
shared_script 'shared/config.lua'
shared_script 'shared/webhook.lua'


dependency 'oxmysql'
