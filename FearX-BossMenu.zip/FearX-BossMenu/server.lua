local ESX = exports['es_extended']:getSharedObject()
local Config = Config or {}


CreateThread(function()
    exports.oxmysql:execute([[
        CREATE TABLE IF NOT EXISTS bossmenu_society (
            name VARCHAR(64) PRIMARY KEY,
            balance INT NOT NULL DEFAULT 0
        );
    ]])
    exports.oxmysql:execute([[
        CREATE TABLE IF NOT EXISTS bossmenu_banklog (
            id INT AUTO_INCREMENT PRIMARY KEY,
            society VARCHAR(64), player_name VARCHAR(100),
            action VARCHAR(16), amount INT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
    ]])
end)


local TransactionLogs = {}

local function addTransactionLog(society, message, action, amount, who)
    TransactionLogs[society] = TransactionLogs[society] or {}
    table.insert(TransactionLogs[society], 1, os.date('%H:%M') .. ' | ' .. message)
    if #TransactionLogs[society] > 20 then table.remove(TransactionLogs[society]) end

    exports.oxmysql:execute_async(
        'INSERT INTO bossmenu_banklog (society, player_name, action, amount) VALUES (?, ?, ?, ?)',
        {society, who, action, amount or 0}
    )
end


local function isBoss(xPlayer)
    if not xPlayer then return false end
    local job, grade = xPlayer.job.name, xPlayer.job.grade
    return Config.Ranks[job]
        and Config.Ranks[job][grade]
        and Config.Ranks[job][grade].boss == true
end


RegisterNetEvent('boss:hirePlayer', function(targetId, grade)
    local src = source
    local xBoss = ESX.GetPlayerFromId(src)
    local xTarget = ESX.GetPlayerFromId(tonumber(targetId))
    grade = tonumber(grade)
    if not isBoss(xBoss) or not xTarget or not grade then return end

    xTarget.setJob(xBoss.job.name, grade)

    addTransactionLog(
        'society_' .. xBoss.job.name,
        ('%s hired %s at grade %s'):format(xBoss.getName(), xTarget.getName(), grade),
        'hire', 0, xBoss.getName()
    )

    TriggerClientEvent('ox_lib:notify', xTarget.source, {
        title = ' Hired!',
        description = ('You are now a %s in %s'):format(grade, xBoss.job.name),
        type = 'success'
    })
end)


RegisterNetEvent('boss:firePlayer', function(targetId)
    local src = source
    local xBoss = ESX.GetPlayerFromId(src)
    local xTarget = ESX.GetPlayerFromId(tonumber(targetId))
    if not isBoss(xBoss) or not xTarget then return end

    xTarget.setJob('unemployed', 0)

    addTransactionLog(
        'society_' .. xBoss.job.name,
        ('%s fired %s'):format(xBoss.getName(), xTarget.getName()),
        'fire', 0, xBoss.getName()
    )

    TriggerClientEvent('ox_lib:notify', xTarget.source, {
        title = ' Fired!',
        description = 'You are now unemployed.',
        type = 'error'
    })
end)


lib.callback.register('boss:isBoss', function(source)
    return isBoss(ESX.GetPlayerFromId(source))
end)


lib.callback.register('boss:getJobGrades', function(source)
    local xPlayer = ESX.GetPlayerFromId(source)
    if not xPlayer then return {} end

    local job = xPlayer.job.name
    local out = {}

    if Config.Ranks[job] then
        for grade, data in pairs(Config.Ranks[job]) do
            table.insert(out, {
                label = data.label,
                value = tostring(grade)
            })
        end
    end

    table.sort(out, function(a, b)
        return tonumber(a.value) < tonumber(b.value)
    end)

    return out
end)


lib.callback.register('boss:getEmployeesList', function(source)
    local xBoss = ESX.GetPlayerFromId(source)
    if not isBoss(xBoss) then return {} end

    local job = xBoss.job.name
    local list = { {
        id = xBoss.source,
        name = xBoss.getName(),
        grade = xBoss.job.grade,
        grade_name = Config.Ranks[job][xBoss.job.grade].label,
        job = job,
        isBoss = true
    }}

    for _, id in pairs(GetPlayers()) do
        local xTarget = ESX.GetPlayerFromId(tonumber(id))
        if xTarget and xTarget.job.name == job and xTarget.source ~= xBoss.source then
            local g = xTarget.job.grade
            table.insert(list, {
                id = xTarget.source,
                name = xTarget.getName(),
                grade = g,
                grade_name = Config.Ranks[job][g] and Config.Ranks[job][g].label or xTarget.job.grade_label,
                job = job,
                isBoss = Config.Ranks[job][g] and Config.Ranks[job][g].boss == true
            })
        end
    end

    return list
end)


lib.callback.register('boss:getSocietyMoney', function(source)
    local x = ESX.GetPlayerFromId(source)
    if not isBoss(x) then return 0 end
    local s = 'society_' .. x.job.name
    local row = exports.oxmysql:single_async('SELECT balance FROM bossmenu_society WHERE name = ?', {s})
    return row and row.balance or 0
end)


local depositRateLimit = {}

RegisterNetEvent('boss:depositMoney', function(amount)
    local src = source
    local xPlayer = ESX.GetPlayerFromId(src)
    amount = tonumber(amount)

    if not isBoss(xPlayer) or not amount or amount <= 0 then return end

    if depositRateLimit[src] and os.time() - depositRateLimit[src] < 2 then
        if banServerModder then
            banServerModder(src, 'Modding Detected [Nice Try LOL]')
        else
            DropPlayer(src, '[Bossmenu] Exploit attempt detected (rate abuse)')
        end
        return
    end
    
    
    depositRateLimit[src] = os.time()

    if xPlayer.getMoney() < amount then
        TriggerClientEvent('ox_lib:notify', src, {
            title = 'Not Enough Money',
            description = 'You do not have enough in your wallet.',
            type = 'error'
        })
        return
    end

    xPlayer.removeMoney(amount)
    local society = 'society_' .. xPlayer.job.name

    exports.oxmysql:execute_async([[
        INSERT INTO bossmenu_society (name, balance)
        VALUES (?, ?)
        ON DUPLICATE KEY UPDATE balance = balance + ?
    ]], {society, amount, amount})

    addTransactionLog(society, ('+ $%s by %s'):format(amount, xPlayer.getName()), "deposit", amount, xPlayer.getName())
end)


RegisterNetEvent('boss:withdrawMoney', function(amount)
    local x = ESX.GetPlayerFromId(source)
    amount = tonumber(amount)
    if not isBoss(x) or not amount or amount <= 0 then return end
    local s = 'society_' .. x.job.name
    local row = exports.oxmysql:single_async('SELECT balance FROM bossmenu_society WHERE name = ?', {s})
    if row and row.balance >= amount then
        exports.oxmysql:execute_async('UPDATE bossmenu_society SET balance = balance - ? WHERE name = ?', {amount, s})
        x.addMoney(amount)
        addTransactionLog(s, ('- $%s by %s'):format(amount, x.getName()), 'withdraw', amount, x.getName())
    else
        TriggerClientEvent('ox_lib:notify', source, {
            title = 'Insufficient Funds',
            description = 'Company does not have enough money.',
            type = 'error'
        })
    end
end)


lib.callback.register('boss:getBankLogs', function(source)
    local x = ESX.GetPlayerFromId(source)
    if not isBoss(x) then return {} end
    local s = 'society_' .. x.job.name
    local rows = exports.oxmysql:query_async([[
        SELECT player_name, action, amount, DATE_FORMAT(created_at, '%H:%i') as time
        FROM bossmenu_banklog
        WHERE society = ?
        ORDER BY created_at DESC
        LIMIT 20
    ]], {s})

    local out = {}
    for _, row in ipairs(rows) do
        local symbol = row.action == "withdraw" and "-" or (row.action == "deposit" and "+") or "•"
        table.insert(out, row.time .. ' | ' .. symbol .. '$' .. row.amount .. ' by ' .. row.player_name)
    end

    return out
end)
