Config = {

    EnableCommand = false,



 -- Add Unlimated Ranks And Jobs - MUST DO
    Ranks = {
        police = {
            [0] = { label = "Cadet", boss = false },
            [1] = { label = "Officer", boss = false },
            [2] = { label = "Sergeant", boss = false },
            [3] = { label = "Lieutenant", boss = false },
            [4] = { label = "Captain", boss = true }
        },
        ambulance = {
            [0] = { label = "EMT", boss = false },
            [1] = { label = "Paramedic", boss = false },
            [2] = { label = "Supervisor", boss = true } -- BOSS
        },
        fearx = {
            [1] = { label = "fearx1", boss = false },
            [2] = { label = "fearx2", boss = false },
            [3] = { label = "fearx3", boss = true } -- BOSS
        },
        mechanic = {
            [0] = { label = "Trainee", boss = false },
            [1] = { label = "Tech", boss = false },
            [2] = { label = "Lead", boss = false },
            [3] = { label = "Boss", boss = true } -- BOSS
        }
    },

 
    BossLocations = {
        {
            job = "police",
            coords = vec3(440.887909, -981.138428, 30.678345),
            label = "Police Department Boss Menu"
        },
        {
            job = "ambulance",
            coords = vec3(306.3, -597.9, 43.3),
            label = "EMS Boss Menu"
        },
        {
            job = "fearx",
            coords = vec3(310.457153, -893.670349, 57.941406),
            label = "FearX Boss Menu"
        },
        {
            job = "mechanic",
            coords = vec3(-211.55, -1324.89, 30.9),
            label = "Bennys Boss Menu"
        }
    },

    -- DO NOT TOUCH 

    
    Marker = {
        draw = true,
        type = 21, -- glowing pillar
        scale = vec3(0.8, 0.8, 1.2),
        color = { r = 0, g = 255, b = 255, a = 200 }
    }
}
