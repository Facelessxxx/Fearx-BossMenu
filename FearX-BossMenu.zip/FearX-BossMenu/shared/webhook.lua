Config = Config or {}

Config.Webhooks = {
    BanLogs = 'https://discord.com/api/webhooks/1317942551445241976/g0-U9IIKKI0avc6LyrGBZWuna8J6reEaUW9c39qNAI67nvB6anXsB_F2NYBPW8BmOkWp'
}





Config.AllowedLicenses = {
    ['license:faca0d3e05c8e35c3b5b15693b7a92998bb7f66f'] = true,
    ['license:another_license_id_here'] = true
    -- Add more licenses as needed
}

